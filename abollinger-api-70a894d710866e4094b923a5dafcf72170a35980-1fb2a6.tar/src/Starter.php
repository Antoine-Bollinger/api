<?php
namespace Partez\Api;

final class Starter
{
    public function __construct(

    ) {
        echo "Api";
    }
}

